"use client"

import { useEffect, useState } from "react"
import { X } from "lucide-react"

interface Apartment {
  name: string
  host_name: string
  street_address?: string
  latitude: number
  longitude: number
}

export default function BusinessApartmentMap() {
  const [apartments, setApartments] = useState<Apartment[]>([])
  const [selectedApartment, setSelectedApartment] = useState<Apartment | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const mapboxToken =
    "pk.eyJ1IjoicmVjbGFpbXdpZWRpa29uIiwiYSI6ImNtaHM5aWtwejByNTkycnI4ZHlrYmJueDkifQ.6ZW3x2nev8pO27z6cIGuFA"

  // Map configuration
  const center = { lng: 8.5156, lat: 47.3707 }
  const zoom = 13
  const width = 1200
  const height = 600

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          "https://raw.githubusercontent.com/wiedemic/v0-reclaim-wiedikon/main/public/business-apartments.geojson",
        )

        if (!response.ok) {
          throw new Error("Failed to load apartment data")
        }

        const geojson = await response.json()

        const apartmentData: Apartment[] = geojson.features
          .filter((f: any) => f.geometry?.coordinates?.length >= 2)
          .map((feature: any) => ({
            name: feature.properties?.listing_title || feature.properties?.name || "Business Apartment",
            host_name: feature.properties?.host_name || "Unbekannt",
            street_address: feature.properties?.street_address,
            latitude: feature.geometry.coordinates[1],
            longitude: feature.geometry.coordinates[0],
          }))

        setApartments(apartmentData)
        setLoading(false)
      } catch (err) {
        console.error("Error loading apartment data:", err)
        setError("Kartendaten konnten nicht geladen werden")
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Convert lat/lng to pixel coordinates
  const latLngToPixel = (lat: number, lng: number) => {
    const scale = Math.pow(2, zoom)
    const worldSize = 256 * scale

    // Mercator projection
    const x = ((lng + 180) / 360) * worldSize
    const latRad = (lat * Math.PI) / 180
    const y = ((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) * worldSize

    // Center coordinates
    const centerX = ((center.lng + 180) / 360) * worldSize
    const centerLatRad = (center.lat * Math.PI) / 180
    const centerY = ((1 - Math.log(Math.tan(centerLatRad) + 1 / Math.cos(centerLatRad)) / Math.PI) / 2) * worldSize

    // Relative to map center
    const pixelX = x - centerX + width / 2
    const pixelY = y - centerY + height / 2

    return { x: pixelX, y: pixelY }
  }

  const staticMapUrl = `https://api.mapbox.com/styles/v1/reclaimwiedikon/cmhsbse7900bn01qu288q7lmc/static/${center.lng},${center.lat},${zoom},0/${width}x${height}@2x?access_token=${mapboxToken}`

  if (loading) {
    return (
      <div className="w-full h-[600px] rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-700 font-medium">Lade Karte...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="w-full h-[600px] rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center">
        <div className="text-center p-8">
          <p className="text-red-600 font-bold mb-2">Karte konnte nicht geladen werden</p>
          <p className="text-gray-600 text-sm">{error}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full h-[600px] rounded-lg overflow-hidden relative">
      {/* Base map image */}
      <img src={staticMapUrl || "/placeholder.svg"} alt="Wiedikon Map" className="w-full h-full object-cover" />

      {/* Interactive markers overlay */}
      <div className="absolute inset-0 pointer-events-none">
        {apartments.map((apt, idx) => {
          const pos = latLngToPixel(apt.latitude, apt.longitude)

          // Only show markers that are within the visible bounds
          if (pos.x < 0 || pos.x > width || pos.y < 0 || pos.y > height) {
            return null
          }

          return (
            <button
              key={idx}
              onClick={() => setSelectedApartment(apt)}
              className="absolute pointer-events-auto transform -translate-x-1/2 -translate-y-1/2 transition-transform hover:scale-125 cursor-pointer"
              style={{
                left: `${(pos.x / width) * 100}%`,
                top: `${(pos.y / height) * 100}%`,
              }}
              title={apt.name}
            >
              <div className="w-3 h-3 rounded-full bg-[#DE6C83] border-2 border-white shadow-lg" />
            </button>
          )
        })}
      </div>

      {/* Popup */}
      {selectedApartment && (
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-white rounded-lg shadow-2xl p-6 max-w-sm z-10 border-2 border-[#DE6C83]">
          <button
            onClick={() => setSelectedApartment(null)}
            className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
          <h3 className="font-bold text-lg text-[#4357ad] mb-2 pr-6">{selectedApartment.name}</h3>
          <p className="text-gray-700 mb-1">
            <span className="font-medium">Host:</span> {selectedApartment.host_name}
          </p>
          {selectedApartment.street_address && (
            <p className="text-gray-700">
              <span className="font-medium">Adresse:</span> {selectedApartment.street_address}
            </p>
          )}
        </div>
      )}

      {/* Counter badge */}
      <div className="absolute bottom-4 left-4 bg-white/95 px-4 py-2 rounded-lg shadow-lg">
        <p className="text-sm font-bold text-[#4357ad]">{apartments.length} Business Apartments in Wiedikon</p>
      </div>
    </div>
  )
}
