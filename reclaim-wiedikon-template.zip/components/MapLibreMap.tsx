"use client"

import { useEffect, useState } from "react"
import Map, { Marker, Popup } from "react-map-gl/maplibre"
import "maplibre-gl/dist/maplibre-gl.css"

interface ApartmentData {
  name: string
  latitude: number
  longitude: number
  price_per_night: number
  host_name: string | null
}

export default function MapLibreMap() {
  const [apartments, setApartments] = useState<ApartmentData[]>([])
  const [selectedApartment, setSelectedApartment] = useState<ApartmentData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadApartments = async () => {
      try {
        const response = await fetch("/wiedikon_markers.json")
        if (!response.ok) {
          throw new Error("Failed to load apartment data")
        }

        const text = await response.text()
        const cleanedText = text.replace(/:\s*NaN/g, ": null")
        const data = JSON.parse(cleanedText)

        setApartments(data)
      } catch (err) {
        console.error("Error loading apartments:", err)
        setError("Failed to load apartment data")
      } finally {
        setLoading(false)
      }
    }

    loadApartments()
  }, [])

  if (loading) {
    return (
      <div className="w-full h-[600px] rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#48a9a6] mx-auto mb-2"></div>
          <p className="text-gray-600">Karte wird geladen...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="w-full h-[600px] rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center">
        <div className="text-center text-red-600">
          <p>Fehler beim Laden der Karte</p>
          <p className="text-sm mt-1">{error}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full h-[600px] rounded-lg overflow-hidden">
      <Map
        initialViewState={{
          latitude: 47.37,
          longitude: 8.515,
          zoom: 13.5,
        }}
        style={{ width: "100%", height: "100%" }}
        mapStyle="https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json"
        attributionControl={false}
      >
        {apartments.map((apartment, index) => (
          <Marker
            key={index}
            latitude={apartment.latitude}
            longitude={apartment.longitude}
            onClick={(e) => {
              e.originalEvent.stopPropagation()
              setSelectedApartment(apartment)
            }}
          >
            <div className="w-4 h-4 bg-[#DE6C83] rounded-full border-2 border-white shadow-lg cursor-pointer hover:scale-110 transition-transform" />
          </Marker>
        ))}

        {selectedApartment && (
          <Popup
            latitude={selectedApartment.latitude}
            longitude={selectedApartment.longitude}
            onClose={() => setSelectedApartment(null)}
            closeButton={true}
            closeOnClick={false}
            className="max-w-xs"
          >
            <div className="p-3">
              <h3 className="font-semibold text-gray-900 mb-2">{selectedApartment.name}</h3>
              <p className="text-sm text-gray-600 mb-1">
                <span className="font-medium">Preis:</span> CHF {selectedApartment.price_per_night}/Nacht
              </p>
              <p className="text-sm text-gray-600">
                <span className="font-medium">Host:</span> {selectedApartment.host_name || "Host nicht verfügbar"}
              </p>
            </div>
          </Popup>
        )}
      </Map>
    </div>
  )
}
