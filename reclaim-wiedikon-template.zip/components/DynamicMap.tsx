"use client"

import { useEffect, useRef, useState } from "react"

interface MarkerData {
  latitude: number
  longitude: number
  name: string
  price: number
  host_name: string | null
}

export default function DynamicMap() {
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let maplibregl: any
    let mapInstance: any

    const initializeMap = async () => {
      try {
        // Dynamic import of maplibre-gl
        maplibregl = await import("maplibre-gl")

        if (map.current || !mapContainer.current) return

        // Initialize map
        mapInstance = new maplibregl.Map({
          container: mapContainer.current,
          style: "https://demotiles.maplibre.org/style.json", // Free demo tiles
          center: [8.515, 47.37], // Zürich Wiedikon
          zoom: 14,
          attributionControl: true,
        })

        map.current = mapInstance

        mapInstance.on("load", async () => {
          try {
            // Load marker data
            const response = await fetch("/wiedikon_markers.json")
            const text = await response.text()
            // Fix NaN values in JSON
            const cleanedText = text.replace(/:\s*NaN/g, ": null")
            const markers: MarkerData[] = JSON.parse(cleanedText)

            // Add markers
            markers.forEach((marker, index) => {
              if (marker.latitude && marker.longitude) {
                // Create marker element
                const el = document.createElement("div")
                el.className = "marker"
                el.style.cssText = `
                  background-color: #DE6C83;
                  width: 20px;
                  height: 20px;
                  border-radius: 50%;
                  border: 2px solid white;
                  cursor: pointer;
                  box-shadow: 0 2px 4px rgba(0,0,0,0.3);
                `

                // Create popup
                const popup = new maplibregl.Popup({ offset: 25 }).setHTML(`
                  <div style="padding: 8px; font-family: system-ui;">
                    <h3 style="margin: 0 0 4px 0; font-weight: bold; color: #333;">${marker.name}</h3>
                    <p style="margin: 0 0 2px 0; color: #666;">CHF ${marker.price}/Nacht</p>
                    <p style="margin: 0; color: #666; font-size: 0.9em;">Host: ${marker.host_name || "Nicht verfügbar"}</p>
                  </div>
                `)

                // Add marker to map
                new maplibregl.Marker(el)
                  .setLngLat([marker.longitude, marker.latitude])
                  .setPopup(popup)
                  .addTo(mapInstance)
              }
            })

            setIsLoading(false)
          } catch (err) {
            console.error("Error loading markers:", err)
            setError("Fehler beim Laden der Marker")
            setIsLoading(false)
          }
        })

        mapInstance.on("error", (e: any) => {
          console.error("Map error:", e)
          setError("Fehler beim Laden der Karte")
          setIsLoading(false)
        })
      } catch (err) {
        console.error("Error initializing map:", err)
        setError("Fehler beim Initialisieren der Karte")
        setIsLoading(false)
      }
    }

    initializeMap()

    // Cleanup
    return () => {
      if (mapInstance) {
        mapInstance.remove()
        map.current = null
      }
    }
  }, [])

  if (error) {
    return (
      <div className="w-full h-[600px] rounded-lg bg-gray-100 flex items-center justify-center">
        <div className="text-center text-gray-600">
          <p className="text-lg font-semibold mb-2">Karte nicht verfügbar</p>
          <p className="text-sm">{error}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="relative w-full h-[600px] rounded-lg overflow-hidden">
      <div ref={mapContainer} className="w-full h-full rounded-lg" style={{ position: "relative" }} />
      {isLoading && (
        <div className="absolute inset-0 bg-gray-100 flex items-center justify-center rounded-lg">
          <div className="text-center text-gray-600">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-600 mx-auto mb-2"></div>
            <p>Karte wird geladen...</p>
          </div>
        </div>
      )}
    </div>
  )
}
