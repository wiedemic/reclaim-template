"use client"

import { useEffect } from "react"

export default function MailerLiteNewsletter() {
  useEffect(() => {
    // Load MailerLite font
    const fontLink = document.createElement("link")
    fontLink.rel = "stylesheet"
    fontLink.href = "https://assets.mlcdn.com/fonts.css?version=1764685"
    document.head.appendChild(fontLink)

    // Load MailerLite script
    const script = document.createElement("script")
    script.src = "https://groot.mailerlite.com/js/w/webforms.min.js?v176e10baa5e7ed80d35ae235be3d5024"
    script.async = true
    document.body.appendChild(script)

    // Track fetch
    fetch("https://assets.mailerlite.com/jsonp/1916798/forms/172670855184123190/takel")

    return () => {
      // Cleanup
      if (fontLink.parentNode) fontLink.parentNode.removeChild(fontLink)
      if (script.parentNode) script.parentNode.removeChild(script)
    }
  }, [])

  return (
    <>
      <style jsx global>{`
        @import url("https://assets.mlcdn.com/fonts.css?version=1764685");
        
        .ml-form-embedSubmitLoad{display:inline-block;width:20px;height:20px}
        .g-recaptcha{transform:scale(1);-webkit-transform:scale(1);transform-origin:0 0;-webkit-transform-origin:0 0}
        .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}
        .ml-form-embedSubmitLoad:after{content:" ";display:block;width:11px;height:11px;margin:1px;border-radius:50%;border:4px solid #fff;border-color:#ffffff #ffffff #ffffff transparent;animation:ml-form-embedSubmitLoad 1.2s linear infinite}
        @keyframes ml-form-embedSubmitLoad{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
        #mlb2-34112584.ml-form-embedContainer{box-sizing:border-box;display:table;margin:0 auto;position:static;width:100%!important}
        #mlb2-34112584.ml-form-embedContainer h4,#mlb2-34112584.ml-form-embedContainer p,#mlb2-34112584.ml-form-embedContainer span,#mlb2-34112584.ml-form-embedContainer button{text-transform:none!important;letter-spacing:normal!important}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper{background-color:#ffffff;border-width:1px;border-color:#e6e6e6;border-radius:0px;border-style:solid;box-sizing:border-box;display:inline-block!important;margin:0;padding:0;position:relative}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper.embedPopup,#mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper.embedDefault{width:400px}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper.embedForm{max-width:400px;width:100%}
        #mlb2-34112584.ml-form-embedContainer .ml-form-align-left{text-align:left}
        #mlb2-34112584.ml-form-embedContainer .ml-form-align-center{text-align:center}
        #mlb2-34112584.ml-form-embedContainer .ml-form-align-default{display:table-cell!important;vertical-align:middle!important;text-align:center!important}
        #mlb2-34112584.ml-form-embedContainer .ml-form-align-right{text-align:right}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody,#mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-successBody{padding:20px 20px 0 20px}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody.ml-form-embedBodyHorizontal{padding-bottom:0}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedContent,#mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-successBody .ml-form-successContent{text-align:left;margin:0 0 20px 0}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedContent h4,#mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-successBody .ml-form-successContent h4{color:#000000;font-family:'Inter',sans-serif;font-size:32px;font-weight:700;margin:0 0 10px 0;text-align:center;word-break:break-word}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedContent p,#mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-successBody .ml-form-successContent p{color:#000000;font-family:'Inter',sans-serif;font-size:16px;font-weight:400;line-height:22px;margin:0 0 10px 0;text-align:left}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedContent p:last-child,#mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-successBody .ml-form-successContent p:last-child{margin:0}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody form{margin:0;width:100%}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-formContent,#mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-checkboxRow{margin:0 0 20px 0;width:100%}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-fieldRow{margin:0 0 10px 0;width:100%}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-fieldRow.ml-last-item{margin:0}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-fieldRow input{background-color:#ffffff!important;color:#333333!important;border-color:#cccccc;border-radius:0px!important;border-style:solid!important;border-width:1px!important;font-family:'Open Sans',Arial,Helvetica,sans-serif;font-size:14px!important;height:auto;line-height:21px!important;margin-bottom:0;margin-top:0;margin-left:0;margin-right:0;padding:10px 10px!important;width:100%!important;box-sizing:border-box!important;max-width:100%!important}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedSubmit{margin:0 0 20px 0;float:left;width:100%}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedSubmit button{background-color:#000000!important;border:none!important;border-radius:0px!important;box-shadow:none!important;color:#ffffff!important;cursor:pointer;font-family:'Inter',sans-serif!important;font-size:16px!important;font-weight:700!important;line-height:21px!important;height:auto;padding:10px!important;width:100%!important;box-sizing:border-box!important}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedSubmit button.loading{display:none}
        #mlb2-34112584.ml-form-embedContainer .ml-form-embedWrapper .ml-form-embedBody .ml-form-embedSubmit button:hover{background-color:#333333!important}
        .ml-error input,.ml-error textarea,.ml-error select{border-color:red!important}
        @media only screen and (max-width:400px){.ml-form-embedWrapper.embedDefault,.ml-form-embedWrapper.embedPopup{width:100%!important}}
      `}</style>

      <div id="mlb2-34112584" className="ml-form-embedContainer ml-subscribe-form ml-subscribe-form-34112584">
        <div className="ml-form-align-center">
          <div className="ml-form-embedWrapper embedForm">
            <div className="ml-form-embedBody ml-form-embedBodyDefault row-form">
              <div className="ml-form-embedContent">
                <h4></h4>
                <p style={{ textAlign: "center" }}>
                  Melde dich für unseren Newsletter an und setze dich für fairen Wohnraum ein
                </p>
              </div>
              <form
                className="ml-block-form"
                action="https://assets.mailerlite.com/jsonp/1916798/forms/172670855184123190/subscribe"
                data-code=""
                method="post"
                target="_blank"
              >
                <div className="ml-form-formContent">
                  <div className="ml-form-fieldRow ml-last-item">
                    <div className="ml-field-group ml-field-email ml-validate-email ml-validate-required">
                      <input
                        aria-label="email"
                        aria-required="true"
                        type="email"
                        className="form-control"
                        data-inputmask=""
                        name="fields[email]"
                        placeholder="Email"
                        autoComplete="email"
                      />
                    </div>
                  </div>
                </div>
                <input type="hidden" name="ml-submit" value="1" />
                <div className="ml-form-embedSubmit">
                  <button type="submit" className="primary">
                    Ich unterstütze das
                  </button>
                  <button disabled style={{ display: "none" }} type="button" className="loading">
                    <div className="ml-form-embedSubmitLoad"></div>
                    <span className="sr-only">Loading...</span>
                  </button>
                </div>
                <input type="hidden" name="anticsrf" value="true" />
              </form>
            </div>
            <div className="ml-form-successBody row-success" style={{ display: "none" }}>
              <div className="ml-form-successContent">
                <h4>Danke für deine Anmeldung</h4>
                <p>
                  <br />
                </p>
                <p style={{ textAlign: "center" }}>
                  Toll, dass du dich für das Anliegen von <strong>#reclaim wiedikon</strong> interessierst.
                </p>
                <p style={{ textAlign: "center" }}>
                  In unserem Newsletter informieren wir dich regelmässig über Aktionen, Recherchen und Entwicklungen
                  rund um Business Apartments und den Wohnraum im Quartier Wiedikon.
                </p>
                <p>
                  <br />
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <script
        dangerouslySetInnerHTML={{
          __html: `
            function ml_webform_success_34112584() {
              var $ = ml_jQuery || jQuery;
              $('.ml-subscribe-form-34112584 .row-success').show();
              $('.ml-subscribe-form-34112584 .row-form').hide();
            }
          `,
        }}
      />
    </>
  )
}
