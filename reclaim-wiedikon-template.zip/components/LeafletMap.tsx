"use client"

import { useEffect } from "react"

export default function LeafletMap() {
  useEffect(() => {
    import("leaflet").then(L => {
      const map = L.map("map", {
        center: [47.37, 8.515],
        zoom: 14,
        zoomControl: true,
      })

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "&copy; OpenStreetMap contributors",
      }).addTo(map)

      fetch("/wiedikon_markers.json")
        .then((res) => res.json())
        .then((data) => {
          data.forEach((apt: any) => {
            L.marker([apt.latitude, apt.longitude])
              .addTo(map)
              .bindPopup(`<strong>${apt.name}</strong><br>CHF ${apt.price} / Nacht<br><em>${apt.host_name}</em>`)
          })
        })
    })
  }, [])

  return (
    <div
      id="map"
      className="w-full h-[600px] rounded-lg z-10"
      style={{ height: "600px", width: "100%", borderRadius: "1rem" }}
    />
  )
}
