import type React from "react"
import type { Metadata } from "next"

import "./globals.css"
import { Inter } from "next/font/google"

const inter = Inter({
  subsets: ["latin"],
  weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
  variable: "--font-inter",
})

export const metadata: Metadata = {
  title: "Reclaim Wiedikon – Wohnraum für Menschen, nicht für Profit",
  description:
    "Eine Initiative gegen die Kommerzialisierung von Wohnraum in Zürich Wiedikon. Wir zeigen, wie Business Apartments den Wohnungsmarkt verdrängen.",
  generator: "v0.app",
  robots: {
    index: true,
    follow: true,
  },
  alternates: {
    canonical: "https://reclaim-wiedikon.ch",
    languages: {
      "de-CH": "https://reclaim-wiedikon.ch",
    },
  },
  openGraph: {
    title: "Reclaim Wiedikon – Wohnraum für Menschen, nicht für Profit",
    description: "Business Apartments verdrängen Wohnraum – wir zeigen die Zahlen.",
    url: "https://reclaim-wiedikon.ch",
    siteName: "Reclaim Wiedikon",
    locale: "de_CH",
    type: "website",
    images: [
      {
        url: "https://reclaim-wiedikon.ch/reclaim_wiedikon_socialimage.jpg",
        width: 1200,
        height: 630,
        alt: "Reclaim Wiedikon – Wohnraum für Menschen, nicht für Profit",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Reclaim Wiedikon",
    description: "Wohnraum statt Business Apartments in Zürich.",
    images: ["https://reclaim-wiedikon.ch/reclaim_wiedikon_socialimage.jpg"],
  },
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/icon.svg", type: "image/svg+xml" },
      { url: "/favicon-96x96.png", sizes: "96x96", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
    other: [
      {
        rel: "mask-icon",
        url: "/icon.svg",
      },
    ],
  },
  manifest: "/site.webmanifest",
  appleWebApp: {
    title: "wiedikon",
  },
  viewport: {
    width: "device-width",
    initialScale: 1.0,
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="de" className={`${inter.variable} antialiased`}>
      <body>{children}</body>
    </html>
  )
}
