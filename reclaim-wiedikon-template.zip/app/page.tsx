"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ExternalLink, Mail, Phone, X, Menu, Instagram } from "lucide-react"
import MailerLiteNewsletter from "@/components/MailerLiteNewsletter"

interface ApartmentData {
  name: string
  latitude: number
  longitude: number
  price: number
  host_name: string | null
}

export default function ReclaimWiedikon() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [formData, setFormData] = useState({
    address: "",
    apartmentType: "",
    listingUrl: "",
    additionalInfo: "",
    email: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
  }

  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth" })
    setMobileMenuOpen(false)
  }

  const [toast, setToast] = useState<{
    visible: boolean
    message: string
    type: "success" | "error"
  }>({
    visible: false,
    message: "",
    type: "success",
  })

  useEffect(() => {
    if (toast.visible) {
      const timer = setTimeout(() => {
        setToast((prev) => ({ ...prev, visible: false }))
      }, 5000)
      return () => clearTimeout(timer)
    }
  }, [toast.visible])

  return (
    <div className="min-h-screen bg-brand-beige text-brand-blue">
      <nav className="fixed top-0 left-0 right-0 backdrop-blur-sm border-b border-brand-blue/20 z-50 text-background border-none bg-accent/95">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex justify-end items-center py-4">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 bg-foreground text-background rounded-md hover:text-[#FC1C7F] transition-colors"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          <div
            className={`overflow-hidden transition-all duration-300 ease-in-out ${
              mobileMenuOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
            }`}
          >
            <div className="py-4 space-y-2 flex flex-col items-end">
              {[
                { id: "map", label: "KARTE" },
                { id: "statistiken", label: "STATISTIKEN" },
                { id: "ueber-uns", label: "ÜBER UNS" },
                { id: "artikel", label: "ARTIKEL" },
                { id: "veranstaltung", label: "VERANSTALTUNG" },
                { id: "newsletter", label: "NEWSLETTER" },
              ].map(({ id, label }) => (
                <button
                  key={id}
                  onClick={() => scrollToSection(id)}
                  className="w-[40%] text-center px-4 py-3 font-bold text-sm tracking-wide bg-foreground text-background hover:text-[#FC1C7F] transition-colors rounded-md"
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      <header className="relative bg-[#FC1C7F] text-foreground min-h-screen flex flex-col items-center justify-center px-4 py-6">
        <div className="flex-1 flex items-center justify-center w-full">
          <div className="w-full max-w-2xl md:max-w-4xl lg:max-w-5xl px-4 animate-in fade-in slide-in-from-bottom-4 duration-1000">
            <img
              src="/images/design-mode/reclaim%20wiedikon.svg"
              alt="# reclaim wiedikon"
              className="w-full h-auto max-w-full"
            />
          </div>
        </div>

        <button
          onClick={() => scrollToSection("intro")}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce cursor-pointer hover:scale-110 transition-transform"
          aria-label="Scroll down"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="32"
            height="32"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-foreground"
          >
            <path d="M12 5v14M19 12l-7 7-7-7" />
          </svg>
        </button>
      </header>

      <section id="intro" className="relative bg-background text-foreground py-12 md:py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl lg:text-6xl font-bold mb-6 md:mb-8 leading-tight">
              Wohnraum für Menschen,
              <br />
              nicht für Profit
            </h2>
            <p className="text-lg md:text-xl lg:text-2xl mb-8 md:mb-12 font-light text-zinc-700">
              Stoppt die Verdrängung durch Business Apartments in Wiedikon
            </p>
            <div className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center">
              <Button
                size="lg"
                onClick={() => scrollToSection("map")}
                className="text-base md:text-lg px-8 md:px-12 py-5 md:py-6 h-auto bg-foreground text-background hover:bg-foreground hover:text-[#FC1C7F] font-bold border-0 transition-colors"
              >
                KARTE ANSEHEN
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section id="map" className="py-12 md:py-24 px-4 bg-secondary">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8 md:mb-16">
            <h2 className="text-3xl md:text-5xl lg:text-6xl font-black mb-4 md:mb-6 text-foreground">
              Business Apartments
              <br />
              in Wiedikon
            </h2>
            <p className="text-base md:text-xl max-w-3xl mx-auto leading-relaxed text-zinc-700 px-4">
              Diese Karte zeigt die Verteilung der Business Apartments in Wiedikon. Der Grossteil dieses Wohnraums wurde
              dem normalen Wohnungsmarkt entzogen.
            </p>
          </div>

          <div className="max-w-6xl mx-auto px-4">
            <Card className="bg-card border-border shadow-lg">
              <CardContent className="p-3 md:p-6">
                <div className="w-full rounded-lg overflow-hidden shadow-lg">
                  <iframe
                    style={{ width: "100%", border: 0 }}
                    className="h-[80vh] md:h-[600px]"
                    allowFullScreen
                    allow="geolocation"
                    src="//umap.openstreetmap.fr/de/map/reclaim-wiedikon_1311440?scaleControl=false&miniMap=false&scrollWheelZoom=false&zoomControl=true&editMode=disabled&moreControl=true&searchControl=null&tilelayersControl=null&embedControl=null&datalayersControl=true&onLoadPanel=none&captionBar=false&captionMenus=true"
                    title="Business Apartments in Wiedikon"
                  />
                </div>
                <div className="mt-6 flex flex-wrap justify-start md:justify-center gap-4 md:gap-6 px-4">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-black rounded-full border-2 border-white shadow-md" />
                    <span className="text-sm md:text-base text-foreground">Daten von insideairbnb.com</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-[#ff1975] rounded-full border-2 border-white shadow-md" />
                    <span className="text-sm md:text-base text-foreground">
                      Recherchierte Daten gemäss Anbieter-Websites
                    </span>
                  </div>
                </div>

                <div className="mt-4 text-left md:text-center">
                  <Button
                    size="sm"
                    asChild
                    className="bg-foreground text-background hover:bg-foreground hover:text-[#FC1C7F] font-bold transition-colors"
                  >
                    <a
                      href="https://umap.openstreetmap.fr/de/map/reclaim-wiedikon_1311440"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Grosse Karte öffnen <ExternalLink className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </div>
                <div className="mt-6 text-left">
                  <p className="text-xs md:text-sm text-gray-500 leading-relaxed">
                    <span className="font-semibold">Hinweise:</span>
                    <br />
                    Karte basierend auf Daten von{" "}
                    <a
                      href="https://insideairbnb.com/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="underline hover:text-brand-pink transition-colors"
                    >
                      insideairbnb.com
                    </a>
                    .
                    <br />
                    Die dargestellten Business Apartments im Kreis 3 umfassen Angebote auf Airbnb – die tatsächliche
                    Anzahl liegt höher, da gewisse kommerzielle Anbieter nicht enthalten sind.
                    <br />
                    Anbieter mit weniger als zwei Inseraten oder einzelnen Zimmern wurden herausgefiltert.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="statistiken" className="py-12 md:py-24 px-4 bg-background">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8 md:mb-16">
            <h2 className="text-3xl md:text-5xl lg:text-6xl font-black mb-4 md:mb-6 text-foreground">
              Die Zahlen
              <br />
              sprechen für sich
            </h2>
            <p className="text-base md:text-xl text-zinc-700">Aktuelle Daten zur Kurzzeitvermietung in Wiedikon</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
            <Card className="bg-card border-border shadow-lg hover:shadow-xl hover:border-foreground transition-all duration-300 hover:-translate-y-2">
              <CardContent className="p-4 md:p-6">
                <div className="bg-secondary-foreground p-6 md:p-8 text-background mb-4 md:mb-6 rounded-lg">
                  <h3 className="text-3xl md:text-4xl font-black mb-2">208</h3>
                  <p className="text-base md:text-lg font-bold uppercase tracking-wide">Business Apartments</p>
                </div>
                <p className="font-medium text-foreground text-sm md:text-base">
                  Anzahl Business Apartments auf Airbnb in Wiedikon
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border shadow-lg hover:shadow-xl hover:border-foreground transition-all duration-300 hover:-translate-y-2">
              <CardContent className="p-4 md:p-6">
                <div className="bg-secondary-foreground p-6 md:p-8 text-background mb-4 md:mb-6 rounded-lg">
                  <h3 className="text-3xl md:text-4xl font-black mb-2">60.1 %</h3>
                  <p className="text-base md:text-lg font-bold uppercase tracking-wide">Marktanteil Top-5</p>
                </div>
                <p className="font-medium text-foreground text-sm md:text-base">
                  Anteil der Business Apartments im Kreis 3, die von den fünf grössten Anbietern kontrolliert werden
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border shadow-lg hover:shadow-xl hover:border-foreground transition-all duration-300 hover:-translate-y-2">
              <CardContent className="p-4 md:p-6">
                <div className="bg-secondary-foreground p-6 md:p-8 text-background mb-4 md:mb-6 rounded-lg">
                  <h3 className="text-3xl md:text-4xl font-black mb-2">44.5 %</h3>
                  <p className="text-base md:text-lg font-bold uppercase tracking-wide">Gewerbliche Angebote</p>
                </div>
                <p className="font-medium text-foreground text-sm md:text-base">
                  Fast die Hälfte aller Airbnb-Inserate im Kreis 3 sind von kommerziellen Anbietern
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border shadow-lg hover:shadow-xl hover:border-foreground transition-all duration-300 hover:-translate-y-2">
              <CardContent className="p-4 md:p-6">
                <div className="bg-secondary-foreground p-6 md:p-8 text-background mb-4 md:mb-6 rounded-lg">
                  <h3 className="text-3xl md:text-4xl font-black mb-2">CHF 164.50</h3>
                  <p className="text-base md:text-lg font-bold uppercase tracking-wide">Preis/Nacht</p>
                </div>
                <p className="font-medium text-foreground text-sm md:text-base">
                  Mittlerer Preis pro Nacht für ein Business Apartment
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border shadow-lg hover:shadow-xl hover:border-foreground transition-all duration-300 hover:-translate-y-2 sm:col-span-2 lg:col-span-2">
              <CardContent className="p-4 md:p-6">
                <div className="bg-secondary-foreground p-6 md:p-8 text-background mb-4 md:mb-6 rounded-lg">
                  <h3 className="text-3xl md:text-4xl font-black mb-2">Fazit</h3>
                  <p className="text-base md:text-lg font-bold uppercase tracking-wide">Bedenkliche Entwicklung</p>
                </div>
                <p className="font-medium text-foreground text-sm md:text-base">
                  Die Daten auf{" "}
                  <a
                    href="https://insideairbnb.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline hover:text-brand-pink transition-colors"
                  >
                    insideairbnb.com
                  </a>{" "}
                  zeigen, dass sich der Kreis 3 zunehmend zu einem professionellen Kurzzeitvermietungsmarkt entwickelt.
                  Kommerzielle Anbieter zielen auf Geschäftsreisende und Relocations – nicht auf klassische
                  Tourist:innen.
                </p>
              </CardContent>
            </Card>
          </div>
          <div className="text-center mt-8 md:mt-12">
            <p className="text-sm md:text-base text-zinc-600 italic">
              Quelle:{" "}
              <a
                href="https://insideairbnb.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="underline hover:text-brand-pink transition-colors"
              >
                insideairbnb.com
              </a>
            </p>
          </div>
        </div>
      </section>

      <section id="ueber-uns" className="py-12 md:py-24 px-4 bg-card-foreground">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8 md:mb-16">
            <h2 className="text-3xl md:text-5xl lg:text-6xl font-black mb-4 md:mb-6 text-white">
              Über
              <br />
              Reclaim Wiedikon
            </h2>
          </div>
          <Card className="bg-card border-card shadow-lg">
            <CardContent className="p-6 md:p-12">
              <div className="space-y-6 md:space-y-8 text-brand-blue leading-relaxed">
                <h3 className="text-2xl md:text-3xl lg:text-4xl font-black mb-4 md:mb-6 text-black">
                  Business Apartments zerstören bezahlbaren Wohnraum.
                </h3>

                <p className="text-base md:text-lg lg:text-xl text-zinc-700">
                  Seit Jahren werden in Wiedikon immer mehr Wohnungen in kommerzielle Business Apartments umgewandelt.
                  Dadurch verlieren wir Woche für Woche bezahlbaren Wohnraum – und damit Platz für Menschen, die hier
                  leben wollen.
                </p>

                <p className="text-base md:text-lg lg:text-xl text-zinc-700">
                  Im September 2021 hat der Gemeinderat –{" "}
                  <a
                    href="https://al-zh.ch/wp-content/uploads/2025/08/gr-2009-534-scherr-motion-zweitwohnungen-odyssee-2009-2024.pdf"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline hover:text-brand-pink transition-colors font-semibold"
                  >
                    nach 11 Jahren Einsatz der Alternativen Liste (AL)
                  </a>{" "}
                  – endlich beschlossen: Diese Umnutzungen sollen nicht mehr als regulärer Wohnraum gelten und in
                  Wohngebieten verboten werden.
                </p>

                <p className="text-base md:text-lg lg:text-xl text-zinc-700">
                  Doch obwohl dieser Entscheid noch vor Bundesgericht hängig ist, könnte der Stadtrat das Verbot bereits
                  heute umsetzen – mit einer sogenannten planerischen Vorwirkung.
                </p>

                <div className="bg-brand-pink/10 p-6 md:p-8 rounded-lg border-l-4 border-accent">
                  <p className="text-lg md:text-xl lg:text-2xl font-bold mb-4 text-black">
                    Doch das Gegenteil passiert: Die Stadt lässt weiterhin neue Business Apartments zu. Das ist
                    verantwortungslos.
                  </p>
                </div>

                <div className="bg-brand-teal/20 p-6 md:p-8 rounded-lg border-l-4 border-emerald-500">
                  <h4 className="text-xl md:text-2xl lg:text-3xl font-black mb-4 md:mb-6 text-foreground">
                    Wir fordern:
                  </h4>
                  <ul className="space-y-3 md:space-y-4 text-base md:text-lg lg:text-xl text-foreground">
                    <li className="flex items-start">
                      <span className="mr-3 font-bold">•</span>
                      <span>{"Sofortiger Zulassungsstopp für alle neuen Business Apartments."}</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-3 font-bold">•</span>
                      <span>Rückgängigmachung aller Umnutzungen seit 2020.</span>
                    </li>
                  </ul>
                </div>

                <p className="text-xl md:text-2xl lg:text-3xl font-black text-center pt-4 md:pt-6 text-black">
                  Reclaim Wiedikon. Reclaim Zürich.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section id="artikel" className="py-12 md:py-24 px-4 bg-zinc-100">
        <div className="max-w-6xl mx-auto text-foreground">
          <div className="text-center mb-8 md:mb-16">
            <h2 className="text-3xl md:text-5xl lg:text-6xl font-black mb-4 md:mb-6 text-black">
              Aktuelle
              <br />
              Artikel
            </h2>
            <p className="text-base md:text-xl text-zinc-700">Berichte und Analysen zur Wohnungssituation in Zürich</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
            {[
              {
                title: "Die Spekulationsspirale dreht weiter",
                summary: "Artikel über die anhaltende Verdrängung in Wiedikon und Spekulation im Wohnungsmarkt.",
                date: "November 2025",
                source: "quartiernetz3.ch",
                link: "https://quartiernetz3.ch/die-spekulationsspirale-dreht-weiter.html",
              },
              {
                title: "«Reclaim Wiedikon»: Mitglieder der AL kämpfen gegen Business-Apartments",
                summary:
                  "Reclaim Wiedikon fordert ein Umdenken im Umgang mit möblierten Kurzzeitwohnungen, um sozialen Wohnraum zu schützen.",
                date: "8. November 2025",
                source: "tsri.ch",
                link: "https://tsri.ch/a/business-apartments-al-will-bewohner-innen-in-wiedikon-aufruetteln",
              },
              {
                title: "Apartments und Zweitwohnungen vor allem in der Innenstadt",
                summary:
                  "Die Zahl der Zweitwohnungen in der Stadt Zürich ist bis September 2025 auf 7620 gestiegen, was 3,2 Prozent des Wohnungsbestands entspricht.",
                date: "13. Nov 2025",
                source: "Stadt Zürich",
                link: "https://www.stadt-zuerich.ch/de/aktuell/medienmitteilungen/2025/11/apartments-zweitwohnungen-innenstadt.html",
              },
              {
                title: "Offener Brief an die Bausektion des Stadtrats",
                summary:
                  "Wohnungsmarkt wird durch Business Apartments ausgehebt – AL fordert endlich Massnahmen zu Sugus-Haus & Co.",
                date: "28. Aug 2025",
                source: "AL Zürich",
                link: "https://al-zh.ch/blog/2025/08/offener-brief/?utm_source=chatgpt.com",
              },
              {
                title: "4,5 Zimmer für 7 500 Franken – Zürichs Königin der Business-Apartments",
                summary:
                  "Die Vermieterin betreibt dutzende luxuriöse Kurzzeit-Wohnungen – ein Beispiel für den boomenden Markt.",
                date: "07. Aug 2025",
                source: "Blick.ch",
                link: "https://www.blick.ch/wirtschaft/4-5-zimmer-fuer-7500-franken-sie-vermietet-in-zuerich-dutzende-teure-business-apartments-id21118570.html",
              },
              {
                title: "Eine Immobilienkönigin überrascht",
                summary:
                  "Anja Graf herrscht in Zürich über ein Reich von 900 Business‑Apartments – und gibt ihren Gegnern recht",
                date: "11. März 2025",
                source: "NZZ",
                link: "https://kdrive.infomaniak.com/app/share/1907102/e556fa23-eaa3-4c59-932d-ff8f827dfc88",
              },
            ].map((article, index) => (
              <Card
                key={index}
                className="bg-card border-none shadow-lg hover:shadow-xl hover:border-foreground transition-all duration-300 hover:-translate-y-2"
              >
                <CardHeader>
                  <CardTitle className="text-lg md:text-xl font-bold text-black hover:text-brand-pink transition-colors">
                    {article.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm md:text-base text-muted-foreground mb-4 md:mb-6 leading-relaxed">
                    {article.summary}
                  </p>
                  <div className="flex justify-between items-center text-xs md:text-sm text-muted-foreground mb-4">
                    <span className="font-medium">{article.date}</span>
                    <span className="font-bold text-foreground">{article.source}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="lg"
                    asChild
                    className="w-full md:w-auto text-sm md:text-base px-6 md:px-8 py-3 md:py-4 h-auto bg-foreground text-background hover:bg-foreground hover:text-[#FC1C7F] font-bold transition-colors"
                  >
                    <a href={article.link} target="_blank" rel="noopener noreferrer">
                      ARTIKEL LESEN <ExternalLink className="w-3 h-3 md:w-4 md:h-4 ml-2" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="veranstaltung" className="py-12 md:py-24 px-4 bg-gradient-to-br from-[#FC1C7F] to-[#e6007e]">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-card border-none shadow-2xl">
            <CardContent className="p-8 md:p-12">
              <div className="space-y-6 md:space-y-8">
                <div>
                  <h3 className="text-2xl md:text-3xl lg:text-4xl font-black mb-6 md:mb-8 text-foreground leading-tight">
                    Ein Spaziergang zu den Business Apartments in Wiedikon
                  </h3>

                  <div className="space-y-4 md:space-y-6">
                    <p className="text-base md:text-lg lg:text-xl text-foreground leading-relaxed">
                      Unser letzter Spaziergang ist vorbei – danke an alle, die dabei waren!
                    </p>

                    <p className="text-base md:text-lg lg:text-xl text-foreground leading-relaxed">
                      Anfang 2026 planen wir einen weiteren Spaziergang durch Wiedikon, um neue Business Apartments zu
                      erkunden und Entwicklungen zu diskutieren.
                    </p>

                    <p className="text-base md:text-lg lg:text-xl text-foreground leading-relaxed font-bold">
                      Melde dich für unseren Newsletter an – wir informieren dich, wann und wo der nächste Spaziergang
                      stattfindet.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Newsletter Section */}
      <section id="newsletter" className="py-12 md:py-24 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="text-center">
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-black mb-4 md:mb-6 text-foreground">
              Mach dich stark für Wiedikon
            </h2>

            <MailerLiteNewsletter />

            <p className="text-sm text-gray-500 mt-4">
              Wir respektieren deine Privatsphäre. Kein Spam, versprochen.
              <br />
              Deine Daten werden sicher in der Schweiz gespeichert und nicht an Dritte weitergegeben.
            </p>
          </div>
        </div>
      </section>

      <footer className="text-background py-8 md:py-12 px-4 bg-foreground">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            <div>
              <h3 className="text-xl md:text-2xl font-bold mb-3 md:mb-4 text-accent">{"# reclaim wiedikon"}</h3>
              <p className="text-sm md:text-base text-background/80 mb-3 md:mb-4">
                Eine Initiative von Menschen aus dem Quartier für bezahlbaren Wohnraum in Wiedikon. Unterstützt von der
                Alternativen Liste Zürich
              </p>
              <p className="text-xs md:text-sm text-accent">Wohnraum für Menschen, nicht für Profit.</p>
            </div>

            <div>
              <h4 className="text-base md:text-lg font-semibold mb-3 md:mb-4">Kontaktiere uns</h4>
              <div className="space-y-2 text-sm md:text-base">
                <div className="flex items-center space-x-2">
                  <Mail className="w-4 h-4 flex-shrink-0" />
                  <a
                    href="mailto:hallo@reclaim-wiedikon.ch"
                    className="break-all hover:text-brand-pink transition-colors"
                  >
                    hallo@reclaim-wiedikon.ch
                  </a>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4 flex-shrink-0" />
                  <a href="tel:+41791234567" className="break-all hover:text-brand-pink transition-colors">
                    +41 79 123 45 67
                  </a>
                </div>
                <div className="flex items-center space-x-2">
                  <Instagram className="w-4 h-4 flex-shrink-0" />
                  <a
                    href="https://www.instagram.com/reclaimwiedikon"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-brand-pink transition-colors"
                  >
                    @reclaimwiedikon
                  </a>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-base md:text-lg font-semibold mb-3 md:mb-4">Links</h4>
              <div className="space-y-2 text-sm md:text-base">
                <a
                  href="https://al-zh.ch/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-background/80 hover:text-brand-pink transition-colors"
                >
                  AL Zürich Website
                </a>
                <a
                  href="https://www.mieterverband.ch/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-background/80 hover:text-brand-pink transition-colors"
                >
                  Mieterverband Zürich
                </a>
                <a
                  href="https://www.stadt-zuerich.ch/de/politik-und-verwaltung/statistik-und-daten/daten/bauen-und-wohnen/wohnungen/zweitwohnungen-und-apartments.html"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-background/80 hover:text-brand-pink transition-colors"
                >
                  Daten Stadt Zürich
                </a>
                <a
                  href="https://al-zh.ch/datenschutzerklaerung/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block text-background/80 hover:text-brand-pink transition-colors"
                >
                  Datenschutz
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-background/20 mt-6 md:mt-8 pt-6 md:pt-8 text-center text-background/60 text-xs md:text-sm">
            <p>© 2025 Reclaim Wiedikon. Alle Rechte vorbehalten.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
