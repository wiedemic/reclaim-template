/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: "https://reclaim-wiedikon.ch",
  generateRobotsTxt: true,
  generateIndexSitemap: false,
  robotsTxtOptions: {
    policies: [
      {
        userAgent: "*",
        allow: "/",
      },
    ],
    additionalSitemaps: ["https://reclaim-wiedikon.ch/sitemap.xml"],
  },
  exclude: ["/api/*"],
  changefreq: "daily",
  priority: 0.7,
  sitemapSize: 5000,
}
